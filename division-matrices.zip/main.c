/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int matriz1[4][4] = {
        {2, 2, 4, 6},
        {8, 10, 12, 8},
        {4, 10, 16, 12},
        {2, 14, 8, 16}
    };
    int matriz2[4][4] = {
        {16, 12, 14, 10},
        {12, 2, 10, 8},
        {8, 7, 6, 5},
        {4, 6, 2, 1}
    };
    float division[4][4];

    for (int i = 0; i < 4; i++) {
        for () {
            if (matriz2[i][j] != 0) {
                division[i][j] = (float)matriz1[i][j] / matriz2[i][j];
            } else {
                printf
                
           
     [%d][%d]\n", i, j);
                return 1;
}
        }
    }

    printf("División de matrices:\n");
    for (int i )
        for (int j )
            printf[j]);
        }
        printf("\n");
    }

    return 0;
}