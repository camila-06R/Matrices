/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//Potencia 
#include <stdio.h>


int main() {
    int matriz[4][4] = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12},
        {13, 14, 15, 16}
    };
    
    
    void multiplicarMatrices(int matriz1[4][4], int matriz2[4][4], int resultado[4][4]) {
    for (int i = 0; i < 4; i++) {
        (int j = 0; j < 4; j++) {
            resultado[i][j] = 0;
            (int k = 0; k < 4; k++) {
                resultado[i][j] += matriz1[i][k] * matriz2[k][j];
            }
        }
    }
}

    
    
    
    return 0;
}